StatsD Go client
================

This is a StatsD client written in Go.

View the project's documentation on godoc: [http://godoc.org/github.com/etsy/statsd/examples/go](http://godoc.org/github.com/etsy/statsd/examples/go)
